codes = {};
function frequency(str){
	var freqs={};
	for(var l in str){
		if (freqs[str[l]] === undefined){
			freqs[str[l]]=1;
		}
		else{
			freqs[str[l]] = freqs[str[l]]+1;
		}
	}
	return freqs;
}
//console.log(frequency('aaabccdeeeeeffg'));
function sortfreq(freqs){
	var tuples=[];
	for (var lt in freqs){
		tuples.push([freqs[lt],lt]);
	}
	return tuples.sort();
}
var w = frequency('malayalam');
tupl=sortfreq(w);
console.log(tupl);
function buildTree(tupl){
	while (tupl.length > 1){
		var leastTwo = [tupl[0][1],tupl[1][1]];
		var rest = tupl.slice(2,tupl.length);
		var fre = tupl[0][0] + tupl[1][0];
		tupl = rest;
		var end = [fre,leastTwo];
		tupl.push(end);
		tupl.sort();
//		console.log(tupl);
	}
	return tupl[0][1];
}
var tree= buildTree(tupl);
console.log(tree);
		
