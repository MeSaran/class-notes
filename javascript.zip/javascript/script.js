
alert("Simple Javascript");
var surname = prompt('Hi, your surname please');
var first = "Saran";
document.getElementById("name").innerHTML=surname;
document.write(first);
var x=25,y=35,i=1;
var sum=x+y;
var clck = function(event) {
	document.getElementById('header-name').style.color="blue";
}
var buttn = document.getElementById("button1");
buttn.addEventListener('click', clck);

function chng(event){
	document.getElementById('para1').innerHTML = first;	
}

var buttn2 = document.getElementById("button2");
buttn2.addEventListener('click',chng)	
	
if (sum>50) { alert("GREATER")
}
document.write(sum)
while (sum<63) { alert(sum);
	sum=sum+1;
}

	
	
