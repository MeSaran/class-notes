var str = 'hello world wass up';
function count(str){
	var dict = {};
	for( var ch in str){
		console.log(dict['h']);
		if (dict[str[ch]] === undefined){
			dict[str[ch]]=1;
		//	console.log(dict);
		}
		else{
			dict[str[ch]] = dict[str[ch]] + 1;
		}
	}
	return dict;
}
rslt = count(str);
//console.log(rslt[1]);
function lst(tupl){
	var tuple=[];
	for (var ch in tupl){
		tuple.push([tupl[ch],ch]);
	}
	return tuple.sort();
}
console.log(lst(rslt))

