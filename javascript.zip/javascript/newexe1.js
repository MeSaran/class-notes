//src="http://cdnjs.cloudflare.com/ajax/libs/jquery/1.9.1/jquery.min.js"><
var str='aaaabccdeeeeeffgf';
//console.log(str);
var arr = [];
var chr='';
var count = 0;
function cont(str,ch){
	var re = new RegExp(ch,"gi");
	return str.match(re).length;
};
function freq(str){
	console.log(str);
	for(var ch=0;ch < str.length ;ch++)
	{
		chr=str[ch];
		var rslt = cont(str,chr);
		arr.push([rslt,chr]);
		//ch = ch + rslt - 2;
	}
	//arr.sort(function(a, b) { return b-a})
	//arr.pop()
	return arr
};
var result = freq(str);
var uniq = [];
var obj = {};
for(var i=0;i < arr.length; i++)
{
	obj[arr[i]] = 0;
}
for(i in obj){
	uniq.push(i);
}
uniq.sort();
console.log(uniq);
var rest=[],nwtup=[],rem=[];
rest=uniq;

function buildtree(rest)
{
	console.log('fucntion');
	while (rest.length > 1){
		var leasttwo = [rest[0][1],rest[1][1]]
		var therest = rest.splice(2,rest.length)  
		var freq = parseInt(rest[0][0]) + parseInt(rest[1][0]);
		var cmb = (freq+leasttwo);
		rest = therest;
		var cmb=[freq,leasttwo];
		console.log(cmb);
		rest.push(cmb);
//	console.log(rest);
		rest.sort();
//	i=i+2;
//	j=j+2;
	}
	return rest[0][1];
}
var newtree = buildtree(rest);
console.log(newtree);
