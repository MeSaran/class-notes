var a,b,sum;
function add(){
	a=document.getElementById('num1').value;
	b=document.getElementById('num2').value;
	sum=parseInt(a)+parseInt(b);
	document.getElementById('rslt').value=sum;
	alert(b);
}
document.getElementById("bt1").addEventListener("click",mul)
