var str = 'w3resourse',newstr='',i=0,ch,list=[];
console.log(str.length);
for(ch = str.length; ch>=0 ; ch--){
	//console.log(newstr);
	newstr = newstr + str[ch];
	//list.push(str[ch]);
	//console.log(newstr[i]);
	//i++;
};
console.log(newstr);
