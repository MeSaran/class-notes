var str='aaaabccdeeeeeffgf';
//console.log(str);
var arr = [];
var chr='';
var count = 0;
function freq(str){
	console.log(str);
	for(var ch=0;ch < str.length ; ch++)
	{
		chr=str[ch];
		console.log(ch);
		for(var j=0; j < str.length ; j++)
		{
			console.log(j)
			if( str[ch] === str[j])
			{
				count++;
			}
			//console.log(str[ch])			
		}
		//console.log(str[ch])
		arr.push({count,chr});
		count=0;
		//console.log(str[ch]);
	}
	return arr
};
var result = freq(str);
console.log(result);
