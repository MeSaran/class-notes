import random
histo={1:'saran', 2:'sarath', 3:'simon', 4:'sam'}
print(histo)
def random_wrd(histo):
        t=[]
        for freq in histo.keys():
                print('word is %s'%(freq))
                t.append(freq)
                print('list')
                print(t)
        return random.choice(t)
r=random_wrd(histo)
print(r)
print(histo[r])

