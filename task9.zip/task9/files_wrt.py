fout=open('textfile.txt','w')
line1 = 'This is Saran here, '
line2 = 'Whats up??'
fout.write(line1)
fout.write(line2)
fout.close() 


