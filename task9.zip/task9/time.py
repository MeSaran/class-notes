class Time:
	def __init__(self,hour=0,minute=0,sec=0):
		self.hour = hour
		self.minute = minute
		self.sec = sec
	def print_time(self):
		print('%.2d:%.2d:%2d'%(self.hour,self.minute,self.sec))
time = Time(6,34,43)
'''time.hour = 6
time.minute = 23
time.sec = 54'''
time.print_time()


