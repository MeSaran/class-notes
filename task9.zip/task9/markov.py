

def process_ln(filename,order=2):
	print('helloooo')
	t=[]
	f=open(filename)
	
	for line in f:
		line=line.lower()
		prefix=' '.join(line.split()[:2])
		process_wrd(prefix,filename)	
def process_wrd(prefix,filename):
	fl=open(filename)
	st=fl.read()
	st=st.lower()
	print(st)
	print(l)	
	if st.find(prefix):
		print('success')
	#(' '.join(line.split()[:2]))
process_ln('mar_msg.txt')
