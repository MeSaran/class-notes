import random
import string
def process_fl(file):
	histo=dict()
	f=open(file)
	for line in f:
		process_ln(line,histo)
	return histo
def process_ln(line,histo):
	line = line.replace('-',' ')
	for word in line.split():
		word = word.strip(string.punctuation + string.whitespace)
		word = word.lower()

		histo[word] = histo.get(word,0) + 1
histo = process_fl('emma.txt')
print(histo)
print(sum(histo.values()))
def most_commn(histo):
	t=[]
	for key,value in histo.items():
		t.append((value,key))
	t.sort(reverse=True)
	#ff=open('b.txt','w')
	#ff.write(str(t))
	#ff.close()	
	#print('Common Words')
	#print(t)
most_commn(histo)
def random_wrd(histo):
	t=[]
	for freq in histo.values():
		#print('word is %d'%(freq))
		t.append(freq)
		#print('list')
		#print(t)
	return random.choice(t)
#print(random_wrd(histo))
print(list(histo.keys())[list(histo.values()).index(random_wrd(histo))])
