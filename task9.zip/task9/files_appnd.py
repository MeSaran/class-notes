fout = open('textfile.txt','a')
line1 = ' Saran is 26 years old'
fout.write(line1)
fout.close()
