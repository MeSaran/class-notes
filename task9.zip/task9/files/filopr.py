import os
str1=''
def sed(pattrn,replc,file1,file2):
	f1=open(file1)
	str1=f1.read()
	print(str1)
	f1.close()
	str2=str1.replace(pattrn,replc)
	try:
		f2=open(file2,'w')
		f2.write(str2)
		f2.close()
	except:
		print('somethings went wrong')
d=sed('is','was','file1.txt','file2.txt')
