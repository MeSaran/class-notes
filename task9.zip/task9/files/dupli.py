import os
import string
st=''
a=[]
match=[]
def srch(dirname):
	#a=[]
	b=[]
	lst = os.listdir(dirname)
	#print(lst)
	#print('----------------------------------')
	for cont in lst:
		#print(cont)
		#print('-------------')
		pat=os.path.join(dirname,cont)
		#print('%s %s'%(cont,pat))
		if os.path.isfile(pat):
			if pat[len(pat)-4:len(pat)] == '.txt':
				b.append(cont)
				cmd = 'md5sum ' + pat
				fp = os.popen(cmd)
				res = fp.read()
				a.append(res)
				fp.close()
		else:
			srch(pat)
	#print('-------md5sum--------')		
	#print(a)
	#st=' '
	#st=str(a)
	#st=st+str(a)
	#dp=st.split()
	#print(dp)
	#for i in range(0,len(dp)):
		#if dp[i] == dp[i+2]:
		#	print('same')
		
	#print('-------file name------')
	#print(b)
	return a
dr=os.getcwd()
op=srch(dr)
st=str(op).split()
print(len(st))
print(st)
'''
for j in range(0,len(st),2):
	if j == 0:
		#print(st[j])
		st[j]=st[j][1:len(st[j])]
	for i in range(2,len(st),2):
		frst=st[j]
		scnd=st[i]
	#print(frst)
	#print(scnd)
		print('%s %s'%(st[j],st[i]))
		if frst == scnd:
			print('match')
			print('i val is%d'%(i))
			match.append(st[i+1])
			#st.insert(i+1,'****')
			#st.remove(frst)
			#st.remove(scnd)
			
print(st)
print('-------------------------------------')
print(match)'''
