class Rect:
	def __init__(self,dx,dy):
		self.dx = dx
		self.dy = dy
	def move_rectangle(self,x,y):
		self.dx = self.dx + x
		print('New x value :%d'%(self.dx))
		self.dy = self.dy + y
		print('New y Value :%d'%(self.dy))
ob=Rect(5,5)
ob.move_rectangle(10,10)
		
