import math
class cal_dist:
	def dist(self,x,y):
		distnc = math.sqrt(float(x)**2 + float(y)**2)
		return distnc
obj = cal_dist()
x = input('Enter value for x')
y = input('Enter value for y')
print(obj.dist(x,y))
