import string
f=open('file1.txt')
print('Contents of file is:')
#print(f.read())
a=''
b=''
a=f.read()
b=a.replace(' ','') 
print(b.split('\n'))

