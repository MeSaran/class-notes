import pickle
fruits=pickle.load(open("fruit.p"))
print(fruits)
