import pickle
#fruits = {'mango' : 10,'apple' : 20,'orange' : 30}
fruits=['apple','orange','pineapple','mango','lemon']
f=open('fruit.p','wb')
pickle.dump(fruits,f)
f.close()


