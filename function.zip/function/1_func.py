# Decorator 
def fun1():
	print('fun 1')

def fnnew(fn):
	def new_fn():
		print('ist is a begining ')
		fn()
	return new_fn
@fnnew
def fun2():
	print('fun 2')
def fun3():
	print('fun 3')
def fun4():
	print('fun 4')

#def fnnew(fn):
#	def new_fn():
#		print('its is the begining of ')
#		fn()
#	return new_fn
#f=fnnew(fun2)
#f()
fun2()
	
