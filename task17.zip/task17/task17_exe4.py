#cummulative product
a = [1, 2, 3, 4, 5]
pro = 1
b = []
for i in range(0,len(a)):
	pro = pro*a[i]
	b.append(pro)
print(a)
print('Cummulative product')
print(b)

