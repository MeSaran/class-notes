t = 1
a=[1, 2, 3, 4, 5]
for i in range(0,len(a)):
	t = t*a[i]
print(t)
