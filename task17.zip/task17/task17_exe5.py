#unique elements
a= [1, 2, 3, 4, 5, 4, 3, 2, 2, 1, 4, 5, 6]
def uniq(a):
	return list(set(a))
p = uniq(a)
print(a)
print('After removing')
print(p)
