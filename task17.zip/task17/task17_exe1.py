import sys
a = sys.argv[1]
b = sys.argv[2]
print('sum is %d'%(int(a)+int(b)))
