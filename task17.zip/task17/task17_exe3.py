#cummulative sum
a = [1, 2, 3, 4, 5]
sum = 0
b = []
for i in range(0,len(a)):
	sum = sum + a[i]
	b.append(sum)
print(b)
