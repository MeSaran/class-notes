class Test(object):
	def __init__(self, min = 0, max = 0):
		self.min = min
		self.max = max
		#self.current = None
	def __getattr__(self, key):
		if key == 'cur':
			return 'Error'
		#self.__dict__[item] = 'Error'
		else:
			raise AttributeError
		#return self.item 
		
ob = Test(10,20)
print(ob.min)
print(ob.max)
print(ob.cur)
