
class Account:
	accnt=0
	def __init__(self,bal=0):
		self.bal = bal
		self.accnt += 1
	def depo(self,amnt):
		self.bal += amnt
	def chckbak(self):
		return self.bal
a=Account(1000)
a.depo(100)
print(a.chckbak())

