class Foo:
	def fun1(self):
		print('fun1 foo')
	def fun2(self):
		print('fun2 foo')
class Bar(Foo):
	def fun1(self):
		print('bar fun1')
b=Bar()
b.fun1()
b.fun2()
