class student:
	pass
def new_stud(name,age,rank):
	s=student()
	s.name=name
	s.age=age
	s.rank=rank
	return s
stud1=new_stud('Raju',24,87)
stud2=new_stud('Alpha',23,78)
def chck(a,b):
	if a.rank > b.rank:
		return a
	else:
		return b
p=chck(stud1,stud2)
print(p.name,p.age,p.rank)
