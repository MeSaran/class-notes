class Test:
#	def __init__(self,x=5):
#		self.x=x
	def show():
		x=10
		print(x)
	def clr():
		x=0
		print(x)
		Test.show()
#f=Test()
Test.show()
Test.clr()
		
