class MyComplex:
	def __init__(self,r,i):	
		self.r=r
		self.i=i
	def add(self,other):
		return MyComplex(self.r+other.r,self.i+other.i)
	def __str__(self):
		return '(%d+%dj)'%(self.r,self.i)

c = MyComplex(1, 2)
d = MyComplex(3, 4)
e=c.add(d)
print(e.r)
print(e.i)
#e=c.add(d)
#e=c+d
print(e)
