class Foo:
	def fun1(self):
		print('fun1')
class Bar(Foo):
	def fun2(self):
		print('fun2')
b=Bar()
b.fun2()
b.fun1()
