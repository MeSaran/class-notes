class Bank:
	def __init__(self,amount=0):
		self.amount=amount
	def  deposit(self,amnt):
		self.amount+=amnt
	def withdraw(self,amnt):
		self.amount-=amnt
	def chckbal(self):
		return self.amount
class LmtAccount(Bank):
	def withdraw(self,amnt):
		if (self.amount - amnt) < 0:
			print( 'can not with draw %d'%(amnt))
		else:
			self.amount-=amnt
a=LmtAccount()
a.deposit(1000)

w=input('Enter the amount to withdrawn')
a.withdraw(int(w))
c=a.chckbal()
print('Balance is %d'%(c))
