class Song(object):
	def __init__(self, lyrics):
		self.lyrics = lyrics
		print(self.lyrics)
	def sing_me_a_song(self):
		for line in self.lyrics:
			print('this is %s'%(line))
happy = Song('hello there')
happy.sing_me_a_song()
'''happy_bday = Song(["Happy birthday to you,",
		     "I don't want to get sued",
		      "So I'will stop right there"])
#bulls_on_parade = Song(["Thery rally around the family",
	  	 	 "with pockets full of shells"])
#happy_bday.sing_me_a_song()
#bulls_on_parade.sing_me_a_song()
'''
