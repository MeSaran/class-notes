class Parent:
	def altered(self):
		print('Parent altered')
	def override(self):
		print('Parent overide')
	def implicit(self):
		print('Parent implicit')
class Child(Parent):
	def altered(self):
		print('child altered,before parent')
		super(Child,self).altered()
		print('Child alered, after parent')
	def override(self):
		print('Child override')
dad = Parent()
son = Child()

dad.implicit()
son.implicit()

dad.override()
son.override()

dad.altered()
son.altered()
