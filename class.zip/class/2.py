class student:
	def __init__(self,name,age,rank):
		self.name=name
		self.age=age
		self.rank=rank
	def __str__(self):
		return 'name %s,age %d,rank %d'%(self.name,self.age,self.rank)

stud1=student('Sam',24,56)
stud2=student('Raju',23,54)
print(stud2)
def chck(a,b):
	if a.rank > b.rank:
		return a
	else:
		return b
x=chck(stud1,stud2)
print(x.name,x.age,x.rank)
