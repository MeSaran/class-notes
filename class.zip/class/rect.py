class Rectangle:
	"pgrm contains rectangle"
	def __init__(self,a,b):
		self.a=a
		self.b=b
	def __lt__(self,other):
		return self.a*self.b < other.a*other.b
	def smaller(self,other):
		"smaller function"
		return self.a*self.b < other.a*other.b
a=Rectangle(3,4)
b=Rectangle(4,5)
print(a.smaller(b))
print(b < a)
