class student:
	def __init__(self,name,age,rank):
		self.name=name
		self.age=age
		self.rank=rank
	def __str__(self):
		return 'name %s,age %d,rank %d'%(self.name,self.age,self.rank)
	def chck(self,other):
		if self.rank > other.rank:
			return self
		else:
			return other
stud1=student('Raju',24,78)
stud2=student('Simon',26,67)
s=stud1.chck(stud2)
print(s)
