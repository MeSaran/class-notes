class Counter:
	#Simple increment program
	def __init__(self,count=0):
		self.a=count
	def __str__(self):
		return 'Counter: %d'%(self.a)
	def show(self):
		print(self.a)
	def increment(self):
		self.a=self.a+1
	def decrement(self):
		self.a -= 1
		#print(self.a)
c=Counter()
c.show()
c.increment()
c.show()
c.decrement()
c.show()
print(c)
c=Counter(10)
c.show()
