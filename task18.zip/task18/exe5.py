"""program to list all files"""
import os
os.system('ls')
