""" simple function to find the square """
def square(x):
	""" computes the square """
	return x*x

